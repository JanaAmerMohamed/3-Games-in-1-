import turtle  # imported turtle module to work on the screen 
wind=turtle.Screen()  # intialize screen
wind.title('PONG GAME')  # to make title to the screen at the top of the screen 
wind.bgcolor('crimson')   # the color of the screen 
wind.setup(width=800, height=600)   # it the lenght of the screen 
wind.tracer(0) # you can control it , so, the page not update itself

#-------------------------------------------------------------------------------------------
   
#madrab1

madrab1=turtle.Turtle() # inializes turtule object( shape)
madrab1.speed(0)  # the speed of the update of the madrab during playing 
madrab1.shape('square')  # the shape of the madrab
madrab1.shapesize(stretch_wid=5,stretch_len=0.5)  # 5*20   #0.5*20  # wid to short or long them # len is thin or big # it is the size of the mabdrab 
madrab1.color('royalblue')  # the color of the madrab
madrab1.penup()   # to prevent draw lines during movements that the tutle do it as normal. 
madrab1.goto(-380,0)  # the location of the madrab 

#----------------------------------------------------------------------------------

#madrab2
madrab2=turtle.Turtle() # inializes turtule object( shape)
madrab2.speed(0)  # the speed of the update of the madrab during playing
madrab2.shape('square') # the shape of the madrab
madrab2.shapesize(stretch_wid=5,stretch_len=0.5)  # 5*20   #0.5*20  # wid to short or long them # len is thin or big 
madrab2.color('black') # the color of the madrab
madrab2.penup()   # to prevent draw lines during movements
madrab2.goto(380,0) # the location of the madrab 

#-------------------------------------------------------------------------------------

# ball
ball=turtle.Turtle() # inializes turtule object( shape)
ball.speed(0) #the speed of the update of the madrab during playing 
ball.shape('circle') # the shape of the ball 


ball.color('navy') # the color of the ball
ball.penup()   # to prevent draw lines during movements
ball.goto(0,0) # the location of the ball 
ball.dx=1 # d is refer to the delta that refer to the change factor # it is the speed of the ball 
ball.dy=1 
#score
score1=0
score2=0
score =turtle.Turtle()
score.speed(0) # the animation speed 
score.color='black'  # the color of the scores 
score.penup()     # to prevent draw of lines on the screen 
score.hideturtle()  # we dont need to see the shape of it  only need the text 
score.goto(0,260)    # the location of the score to appear 
score.write('player 1: 0 player 2: 0', align='center', font=('Courier',24,'bold'))  # the score appear at the center and contain player1 and player 2

#--------------------------------------------------------------------------------------------------------

def madrab1_up():    # to move the madrab up 
    y=madrab1.ycor()  # it tells the location of the object right now at the y axis 
    y+=25     # increse the location of the madrab when you move by 25 
    madrab1.sety(y)  # to change the old location to the update location of the madrab 
    
#keyboard 
wind.listen()  # this tell that there is order come from the keyboard
wind.onkeypress(madrab1_up,'Up')   # this mean when up bottom enter it will give order to the function of the (madrab1_up) to work 
#-------------------------------------------------------------
   
def madrab1_down():   # to move the madrab down
    y=madrab1.ycor()  # it tells the location of the object right now at the y axis 
    y-=25 # decrease the location of the madrab when you move by 25 
    madrab1.sety(y)   # to change the old location to the update location of the madrab  
    
#keyboard 
wind.listen() # this tell that there is order come from the keyboard
wind.onkeypress(madrab1_down,'Down')  # this mean when Down bottom enter it will give order to the function of the (madrab1_up) to work

#-------------------------------------------------------------------

def madrab2_up():
    y=madrab2.ycor()
    y+=25
    madrab2.sety(y)
    
#keyboard 
wind.listen()
wind.onkeypress(madrab2_up,'w')
#-------------------------------------------------------------
   
def madrab2_down():
    y=madrab2.ycor() 
    y-=25
    madrab2.sety(y)    
    
#keyboard 
wind.listen()
wind.onkeypress(madrab2_down,'s')

#-------------------------------------------------------------------


while True :   # the loop of the game 
    wind.update()  # update to the screen everytime the loop run  
    
    
    #move of ball
    ball.setx(ball.xcor() +ball.dx) # this to  identify the new location of the ball at x axis  by ( location of the ball now + the change of the ball (delta))
    ball.sety(ball.ycor() +ball.dy) # this to  identify the new location of the ball at y axis  by ( location of the ball now + the change of the ball (delta))
    
    #border check  to not make the ball go away from the screen edge   top border +300px  below border -300 px  ball is 20 px
    
    if ball.ycor()>290:  # the location of the ball now at top border 
        ball.sety(290)  #  this mean to return the ball to the 290 
        ball.dy*=-1  # multiply the delta to (-1) to make the change so, it will be -1 so, it will return to the opposite side # reverse the x direction
        
    if ball.ycor()<-290:  # the location of the ball now at below  border 
        ball.sety(-290) # return the ball to 290
        ball.dy*=-1    # multiply the delta to (-1) to make the change so, it will be -1  so, it will return to the opposite side # reverse the x direction
        
    if ball.xcor()>390:  # the location of the ball now at right border 
        ball.goto(0,0)  # to return the ball to the center 
        
        ball.dx*=-1  # multiply the delta to (-1) to make the change so, it will be -1  so, it will return to the opposite side  # reverse the x direction
        
        score1 +=1   # to change the score 
        score.clear() # to remove the last result and add the new one,  to prevent print the old on new 
        score.write('player 1: {} player 2: {}'.format(score1, score2), align='center', font=('Courier',24,'bold')) 
        
    if ball.xcor()<-390:  # the location of the ball now  at the left border 

        ball.goto(0,0)   # to return the ball to the center 
             
        ball.dx*=-1    # multiply the delta to (-1) to make the change so, it will be -1  so, it will return to the opposite side  # reverse the x direction 
        score2 +=1  # change the score 
        score.clear()  # to remove the last result and add the new one,  to prevent print the old on new 
        score.write('player 1: {} player 2: {}'.format(score1,score2), align='center', font=('Courier',24,'bold')) 
                
        
     # tasadom the ball with the madrab
     
     # madrab2 with the ball 
     
    if (ball.xcor()>375 and ball.xcor()<380) and (ball.ycor()<madrab2.ycor() +40 and ball.ycor()>madrab2.ycor() -40):
        ball.setx(375)
        ball.dx*=-1
    # madrab1 with the ball    
    if (ball.xcor()<-375 and ball.xcor()>-380) and (ball.ycor()<madrab1.ycor() +40 and ball.ycor()>madrab1.ycor() -40):
        ball.setx(-375)
        ball.dx*=-1        
                                                
                                                
                                         
    

    
