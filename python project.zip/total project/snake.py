import pygame
import random

pygame.init()

white = (255, 255, 255)
yellow = (219, 235, 52)
black = (0, 0, 0)
red = (235, 52, 52)
green = (113, 235, 52)


screen_width = 600
screen_height = 400

screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Snake Game")

snake_block = 10
snake_speed = 20

font_style = pygame.font.SysFont("bahnschrift", 20)
score_font = pygame.font.SysFont("bahnschrift", 35)


def score(score):
    value = score_font.render("Your Score: " + str(score), True, green)
    screen.blit(value, [0, 0])


def snake_body(snake_block, snake_list):
    for x in snake_list:
        pygame.draw.rect(screen, white, [x[0], x[1], snake_block, snake_block])


def message(msg, color):
    mesg = font_style.render(msg, True, color)
    screen.blit(mesg, [screen_width / 6, screen_height / 3])


def run():
    game_over = False
    close = False

    x1 = screen_width / 2
    y1 = screen_height / 2

    new_x = 0
    new_y = 0

    snake_List = []
    snake_length = 1

    foodx = round(random.randrange(0, screen_width - snake_block) / 10.0) * 10.0
    foody = round(random.randrange(0, screen_height - snake_block) / 10.0) * 10.0

    while game_over == False:

        while close == True:
            screen.fill(black)
            message("Game over! press Enter to play again, or Esc to quit", red)
            score(snake_length - 1)
            pygame.display.update()

            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        game_over = True
                        close = False
                    if event.key == pygame.K_KP_ENTER:
                        run()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_over = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    new_x = -snake_block
                    new_y = 0
                elif event.key == pygame.K_RIGHT:
                    new_x = snake_block
                    new_y = 0
                elif event.key == pygame.K_UP:
                    new_y = -snake_block
                    new_x = 0
                elif event.key == pygame.K_DOWN:
                    new_y = snake_block
                    new_x = 0

        if x1 >= screen_width or x1 < 0 or y1 >= screen_height or y1 < 0:
            close = True
        x1 += new_x
        y1 += new_y
        screen.fill(black)
        pygame.draw.rect(screen, yellow, [foodx, foody, snake_block, snake_block])
        snake_head = []
        snake_head.append(x1)
        snake_head.append(y1)
        snake_List.append(snake_head)
        if len(snake_List) > snake_length:
            del snake_List[0]

        for x in snake_List[:-1]:
            if x == snake_head:
                close = True

        snake_body(snake_block, snake_List)
        score(snake_length - 1)

        pygame.display.update()

        if x1 == foodx and y1 == foody:
            foodx = round(random.randrange(0, screen_width - snake_block) / 10.0) * 10.0
            foody = round(random.randrange(0, screen_height - snake_block) / 10.0) * 10.0
            snake_length += 1

        pygame.time.Clock().tick(snake_speed)

    pygame.quit()
    quit()
run()
