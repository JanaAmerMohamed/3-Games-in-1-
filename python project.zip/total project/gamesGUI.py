import tkinter as tk

HEIGHT=200
WIDTH=200

def snakeGame():
    import snake.py

def ticTacToeGame():
    import ticTacToe.py

def pingponggame():
    import pingpong.py

def flappybirdgame():
    import flappybird.py

root=tk.Tk()

canvas=tk.Canvas(root, height=HEIGHT, width=WIDTH)
canvas.pack()


button1=tk.Button(root, text="Snake", bg='gray' ,activebackground='#eb4034',command=snakeGame)
button1.place(relx=0.1,rely=0.4,relheight=0.2,relwidth=0.3)

button2=tk.Button(root, text="Tic-Tac-Toe", bg='gray', activebackground='#eb4034',command=ticTacToeGame)
button2.place(relx=0.5,rely=0.4,relheight=0.2,relwidth=0.4)

button3=tk.Button(root,text="ping pong", bg='gray',activebackground='#eb4034',command=pingponggame)
button3.place(relx=0.1,rely=0.7,relheight=0.2,relwidth=0.3)

button3=tk.Button(root,text="flappy bird", bg='gray',activebackground='#eb4034',command=flappybirdgame)
button3.place(relx=0.5,rely=0.7,relheight=0.2,relwidth=0.4)


root.mainloop()
