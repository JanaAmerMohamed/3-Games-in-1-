from tkinter import *
from tkinter import messagebox
root = Tk()
root.title("Tic Tac TOE Game")
Toe= True
counter=0
def stop_everything():
        s1.config(state=DISABLED)
        s2.config(state=DISABLED)
        s3.config(state=DISABLED)
        s4.config(state=DISABLED)
        s5.config(state=DISABLED)
        s6.config(state=DISABLED)
        s7.config(state=DISABLED)
        s8.config(state=DISABLED)
        s9.config(state=DISABLED)        
def winning() :
    global congrats
    congrats=False
    if s1["text"]=="O"and s2["text"]=="O" and s3["text"]=="O":
        s1.config(bg="red")
        s2.config(bg="red")
        s3.config(bg="red")
        congrats=True
        messagebox.showinfo("Great job!" ,"O is the winner")
        stop_everything()
        
    elif s4["text"]=="O"and s5["text"]=="O" and s6["text"]=="O":
        s4.config(bg="red")
        s5.config(bg="red")
        s6.config(bg="red")
        congrats=True
        messagebox.showinfo("Great job!" ,"O is the winner")
        stop_everything()     
    elif s7["text"]=="O"and s8["text"]=="O" and s9["text"]=="O":
        s7.config(bg="red")
        s8.config(bg="red")
        s9.config(bg="red")
        congrats=True
        messagebox.showinfo("Great job!" ,"O is the winner")
        stop_everything()     
    elif s1["text"]=="O"and s4["text"]=="O" and s7["text"]=="O":
        s1.config(bg="red")
        s4.config(bg="red")
        s7.config(bg="red")
        congrats=True
        messagebox.showinfo("Great job!" ,"O is the winner")
        stop_everything()     
    elif s2["text"]=="O"and s5["text"]=="O" and s8["text"]=="O":
        s2.config(bg="red")
        s5.config(bg="red")
        s8.config(bg="red")
        congrats=True
        messagebox.showinfo("Great job!" ,"O is the winner")
        stop_everything()     
    elif s3["text"]=="O"and s6["text"]=="O" and s9["text"]=="O":
        s3.config(bg="red")
        s6.config(bg="red")
        s9.config(bg="red")
        congrats=True
        messagebox.showinfo("Great job!" ,"O is the winner")
        stop_everything()     
    elif s1["text"]=="O"and s5["text"]=="O" and s9["text"]=="O":
        s1.config(bg="red")
        s5.config(bg="red")
        s9.config(bg="red")
        congrats=True
        messagebox.showinfo("Great job!" ,"O is the winner")
        stop_everything()     
    elif s3["text"]=="O"and s5["text"]=="O" and s7["text"]=="O":
        s3.config(bg="red")
        s5.config(bg="red")
        s7.config(bg="red")
        congrats=True
        messagebox.showinfo("Great job!" ,"O is the winner")
        stop_everything()     
    elif s1["text"]=="X"and s2["text"]=="X" and s3["text"]=="X":
        s1.config(bg="red")
        s2.config(bg="red")
        s3.config(bg="red")
        congrats=True
        messagebox.showinfo("Great job!" ,"X is the winner")
        stop_everything()
    elif s4["text"]=="X"and s5["text"]=="X" and s6["text"]=="X":
        s4.config(bg="blue")
        s5.config(bg="blue")
        s6.config(bg="blue")
        congrats=True
        messagebox.showinfo("Great job!" ,"X is the winner")
        stop_everything()     
    elif s7["text"]=="X"and s8["text"]=="X" and s9["text"]=="X":
        s7.config(bg="blue")
        s8.config(bg="blue")
        s9.config(bg="blue")
        congrats=True
        messagebox.showinfo("Great job!" ,"X is the winner")
        stop_everything()     
    elif s1["text"]=="X"and s4["text"]=="X" and s7["text"]=="X":
        s1.config(bg="blue")
        s4.config(bg="blue")
        s7.config(bg="blue")
        congrats=True
        messagebox.showinfo("Great job!" ,"X is the winner")
        stop_everything()     
    elif s2["text"]=="X"and s5["text"]=="X" and s8["text"]=="X":
        s2.config(bg="blue")
        s5.config(bg="blue")
        s8.config(bg="blue")
        congrats=True
        messagebox.showinfo("Great job!" ,"X is the winner")
        stop_everything()     
    elif s3["text"]=="X"and s6["text"]=="X" and s9["text"]=="X":
        s3.config(bg="blue")
        s6.config(bg="blue")
        s9.config(bg="blue")
        congrats=True
        messagebox.showinfo("Great job!" ,"X is the winner")
        stop_everything()     
    elif s1["text"]=="X"and s5["text"]=="X" and s9["text"]=="X":
        s1.config(bg="blue")
        s5.config(bg="blue")
        s9.config(bg="blue")
        congrats=True
        messagebox.showinfo("Great job!" ,"X is the winner")
        stop_everything()     
    elif s3["text"]=="X"and s5["text"]=="X" and s7["text"]=="X":
        s3.config(bg="blue")
        s5.config(bg="blue")
        s7.config(bg="blue")
        congrats=True
        messagebox.showinfo("Great job!" ,"X is the winner")
        stop_everything()
    if counter==9 and congrats==False:
            messagebox.showinfo("What a game","It's a draw")
            
def play(s):
    global Toe, counter
    if s["text"]=="" and Toe== True:
        s["text"]="O"
        Toe= False
        counter+=1
        winning()
    elif s["text"]=="" and Toe== False:
        s["text"]="X"
        Toe= True
        counter+=1
        winning()
    else:
        messagebox.showerror("Not valid","Try another square")
        
def clear():
        global s1,s2,s3,s4,s5,s6,s7,s8,s9
        global Toe, counter
        Toe=True
        counter=0
        s1= Button(root,text="",height=4,width=8,bg="white",font=("MS Sans Serif",22),command= lambda:play(s1))
        s2= Button(root,text="",height=4,width=8,bg="white",font=("MS Sans Serif",22),command= lambda:play(s2))
        s3= Button(root,text="",height=4,width=8,bg="white",font=("MS Sans Serif",22),command= lambda:play(s3))
        s4= Button(root,text="",height=4,width=8,bg="white",font=("MS Sans Serif",22),command= lambda:play(s4))
        s5= Button(root,text="",height=4,width=8,bg="white",font=("MS Sans Serif",22),command= lambda:play(s5))
        s6= Button(root,text="",height=4,width=8,bg="white",font=("MS Sans Serif",22),command= lambda:play(s6))
        s7= Button(root,text="",height=4,width=8,bg="white",font=("MS Sans Serif",22),command= lambda:play(s7))
        s8= Button(root,text="",height=4,width=8,bg="white",font=("MS Sans Serif",22),command= lambda:play(s8))
        s9= Button(root,text="",height=4,width=8,bg="white",font=("MS Sans Serif",22),command= lambda:play(s9))
        s1.grid(row=0,column=0)
        s2.grid(row=0,column=1)
        s3.grid(row=0,column=2)
        s4.grid(row=1,column=0)
        s5.grid(row=1,column=1)
        s6.grid(row=1,column=2)
        s7.grid(row=2,column=0)
        s8.grid(row=2,column=1)
        s9.grid(row=2,column=2)
Again = Menu(root)
root.config(menu=Again)
options_menu = Menu(Again, tearoff=False)
Again.add_cascade(label="Options", menu=options_menu)
options_menu.add_command(label="clear all", command=clear)
clear()

           
root.mainloop()
